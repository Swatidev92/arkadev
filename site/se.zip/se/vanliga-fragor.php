<link rel="stylesheet" type="text/css" href="<?=SITE_PATH?>assets/css/inner-custom.css" />

	<div class="faq-section default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="sw_left_heading_wraper">
						<h1><span class="heading-bold">Frequently Asked Questions</span></h1>
					</div>
				</div>
			</div>
					
				
			<div class="row">
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
					<div class="sw_left_heading_wraper">
						<h1><span class="heading-bold">Services</span></h1>
					</div>
				</div>
                <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_leads_accordian">
                            <div class="panel-group" id="accordionFifteenLeft" role="tablist">
                               
                                <!-- /.panel-default -->
                                <div class="panel panel-default">
                                    <div class="panel-heading horn">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftFive" aria-expanded="false">What is a home storage battery and how does it work?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftFive" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="panel panel-default">
                                    <div class="panel-heading horn">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftTwo" aria-expanded="false">Why do I need a home battery for solar energy?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftTwo" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.panel-default -->
                                <div class="panel panel-default">
                                    <div class="panel-heading bell">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftThree" aria-expanded="false">How do you install a solar battery at home?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftThree" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading bell">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftFour" aria-expanded="false">Can you get a subsidy for installing a home storage battery?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftFour" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
								<div class="panel panel-default">
                                    <div class="panel-heading desktop">
                                        <h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftone" aria-expanded="true">How much does a solar battery with installation cost?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftone" class="panel-collapse collapse in" aria-expanded="true" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			<div class="row">
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
					<div class="sw_left_heading_wraper">
						<h1><span class="heading-bold">Services</span></h1>
					</div>
				</div>
                <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_leads_accordian">
                            <div class="panel-group" id="accordionFifteenLeft" role="tablist">
                               
                                <!-- /.panel-default -->
                                <div class="panel panel-default">
                                    <div class="panel-heading horn">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftFive" aria-expanded="false">What is a home storage battery and how does it work?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftFive" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="panel panel-default">
                                    <div class="panel-heading horn">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftTwo" aria-expanded="false">Why do I need a home battery for solar energy?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftTwo" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.panel-default -->
                                <div class="panel panel-default">
                                    <div class="panel-heading bell">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftThree" aria-expanded="false">How do you install a solar battery at home?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftThree" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading bell">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftFour" aria-expanded="false">Can you get a subsidy for installing a home storage battery?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftFour" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
								<div class="panel panel-default">
                                    <div class="panel-heading desktop">
                                        <h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftone" aria-expanded="true">How much does a solar battery with installation cost?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftone" class="panel-collapse collapse in" aria-expanded="true" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
	</div>