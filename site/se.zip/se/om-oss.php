	<link rel="stylesheet" type="text/css" href="<?=SITE_PATH?>assets/css/inner-custom.css" />

	<div class="page-head-banner" style="background: url(<?=SITE_PATH?>assets/images/about/Rectangle-109.png); background-position: center bottom; background-repeat: no-repeat; background-size: cover;">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="content-banner" style="margin-top:60px;">
						<h2>About us</h2> 
						<div class="about-join-banner">
							<a href="#" class="black-text">Join Us</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	 
	 
	<!-- sw choose service wrapper start-->
    <div class="sw_chose_service_wrapper default-padding">
        <div class="container">
			<div class="row">
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_left_heading_wraper">
                            <h1 style="line-height:1.2">Arka Belief</h1>
                        </div>
					</div>
				</div>
			
				<div class="col-lg-8 col-md-8 col-xs-12 col-sm-6">
					<div class="">
						<p class="para-content">For a long time, we have been consuming electricity in the same way. We are here to change the status quo and we are on a mission to enable every individual to produce their own electricity.</p>
						<p class="para-content">We have a global experience of over 800 MW and 10,000 Homes going solar. This makes us one of the most experienced companies in Sweden. </p>
						<p class="para-content">We develop and maintain every single solar plant and relationship with great care as we know it is going to take us a long way.</p>
					</div>
				</div>			
			</div>
		</div>
    </div>
    <!-- sw choose service wrapper end-->
	
	
    <div class="default-padding">
        <div class="container">
			<div class="row">
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_left_heading_wraper">
                            <h1 style="line-height:1.2"><span class="heading-bold">Our values</span></h1>
                        </div>
					</div>
				</div>
			
				<div class="col-lg-8 col-md-8 col-xs-12 col-sm-6">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
							<div class="value-box">
								<div class="value-img-icon">
									<img src="<?=SITE_PATH?>assets/images/about/enterpreneurship.png" alt="title">
								</div>
								<div class="gb_icon_content"><b>Entrepreneurship</b></div>
								<p class="value-short-text">We passionately challenge the status-quo by encouraging bold thinking, initiatives and exploring unconventional ideas</p>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
							<div class="value-box">
								<div class="value-img-icon">
									<img src="<?=SITE_PATH?>assets/images/about/Transprency.png" alt="title">
								</div>
								<div class="gb_icon_content"><b>Transparency</b></div>
								<p class="value-short-text">Information and experiences, successes and failures, good news and bad news – we share openly. It makes us all stronger</p>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
							<div class="value-box">
								<div class="value-img-icon">
									<img src="<?=SITE_PATH?>assets/images/about/honesty.png" alt="title">
								</div>
								<div class="gb_icon_content"><b>Honesty</b></div>
								<p class="value-short-text">«Honesty» to us means sincerity, truthfulness, fair & loyal with integrity</p>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
							<div class="value-box">
								<div class="value-img-icon">
									<img src="<?=SITE_PATH?>assets/images/about/excellence.png" alt="title">
								</div>
								<div class="gb_icon_content"><b>Excellence</b></div>
								<p class="value-short-text">To us «Excellence» means standing out, striving for perfection in everything we do</p>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
							<div class="value-box">
								<div class="value-img-icon">
									<img src="<?=SITE_PATH?>assets/images/about/Socially-responsible.png" alt="title">
								</div>
								<div class="gb_icon_content"><b>Socially Responsible</b></div>
								<p class="value-short-text">We are committed to care for the society and environment through all our actions</p>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-xs-12 col-sm-12">
							<div class="value-box">
								<div class="last-col-content"><b>Our planet has to<br>shift to solar<br>power and we<br>have made it our<br>job to get it done</b></div>
							</div>
						</div>
					</div>
				</div>				
			</div>
			<div class="row">
				<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="disc_btn1 ltr_btn1 text-right">
						<ul class="service-align-btns">
							<li><a href="#!" class="waves-effect waves-light waves-ripple">Join Us</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
    </div>
	
	
	<div class="default-padding1">
        <div class="container">
			<div class="row">
				<div class="col-lg-2 col-md-2 col-xs-12 col-sm-12">
					<div class="count-box">
						<h2 class="count-text">10k</h2>
						<div class="gb_icon_content"><b>Homes</b></div>
					</div>
				</div>
				<div class="col-lg-2 col-md-2 col-xs-12 col-sm-12">
					<div class="count-box">
						<h2 class="count-text">150</h2>
						<div class="gb_icon_content"><b>Experts</b></div>
					</div>
				</div>
				<div class="col-lg-3 col-md-3 col-xs-12 col-sm-12">
					<div class="count-box">
						<h2 class="count-text">240+</h2>
						<div class="gb_icon_content"><b>Healthy Clients</b></div>
					</div>
				</div>
				<div class="col-lg-5 col-md-5 col-xs-12 col-sm-12">
					<div class="count-box">
						<h2 class="count-text">800+ MW</h2>
						<div class="gb_icon_content"><b>Projects Commissioned</b></div>
					</div>
				</div>
			</div>
		</div>
    </div>
	
	
	
    <div class="about-green-banner">
        <div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="text-center">
						<h2 class="about-joinus"><b>Our planet has to shift to solar power and we<br>have made it our job to get it done.</b></h2>
					</div>
					<div class="">
						<div class="disc_btn1 ltr_btn1 text-center">
							<ul class="about-joinus">
								<li><a href="#!" class="waves-effect waves-light waves-ripple">Join Us</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>