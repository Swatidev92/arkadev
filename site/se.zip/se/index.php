	<div class="page-head-banner" style="background: url(<?=SITE_PATH?>assets/images/banners/Banner.jpg); background-position: center bottom; background-repeat: no-repeat; background-size: cover;">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="content-banner">
						<h2>Investera i en hållbar framtid drivs av arka</h2>  
						<div class="banner-input-box">
							<div class="row">
								<div class="col-md-5">
									<input type="text" name="" placeholder="Skriv in din mailadress" class="banner-address-input">
								</div>
								<div class="col-md-1">
									<a href=""> 
										<img src="<?=SITE_PATH?>assets/images/green-btn.png" class="banner-green-btn">
									</a>
								</div>
							</div>
						</div>
						<div class="banner-call-btn">
							<a href="tel:011 171 3640"> 
								<img src="<?=SITE_PATH?>assets/images/phone-banner.png"> 
								<span class="calling-number">011 171 3640</span>
							</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
										
										
	<!-- sw choose service wrapper start-->
    <div class="sw_chose_service_wrapper default-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                    <div class="sw_left_heading_wraper sw_center_heading_wrapper">
                        <h1><span class="heading-bold">Vad gör Arka till det bästa valet?</span></h1>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                    <div class="chose_text_wrapper_left">
                        <div class="chose_icon_wrapper_list">
                            <div class="chose_icon_content_left">
                                <h1 class="text1">11 års</h1>
                                <h5 class="text2">global erfarenhet</h5>
                                <p class="arka-best-choice-text">Vi är baserade på 3 kontinenter och över 11 år har genomfört mer än 10 000 bostäder och 700 MW-installationer.</p>
                            </div>
                        </div>                   
                    </div>
                </div>
				 
                <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                    <div class="chose_text_wrapper_left">
                        <div class="chose_icon_wrapper_list">
                            <div class="chose_icon_content_left">
                                <h1 class="text1">100%</h1>
                                <h5 class="text2">Problemfri lösning</h5>
                                <p class="arka-best-choice-text">Vi tillhandahåller nyckelfärdiga tjänster, vare sig det är bäst i klassdesign, urval av bästa produkter eller att få godkännanden, vi tar hand om det åt dig. Och när vi väl är live underhåller vi ditt system under hela livet för att säkerställa 0 krångel för dig.</p>
                            </div>
                        </div>                      
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                    <div class="chose_text_wrapper_left">
                        <div class="chose_icon_wrapper_list">
                            <div class="chose_icon_content_left">
                                <h1 class="text1">Livstid</h1>
								<h5 class="text2">Underhållsstöd</h5>
                                <p class="arka-best-choice-text">Vi är här på lång sikt. När vi har installerat systemet ser vi till att vi besöker dig regelbundet eller när du behöver oss för att hålla solcentralen igång så att du får en optimal återbetalningsperiod.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 visible-sm visible-xs">
                    <div class="section2_img_wrapper wow  bounceIn animated" data-wow-duration="1.3s" style="visibility: visible; animation-duration: 1.3s; animation-name: bounceIn;">
                        <img class="img-responsive" src="<?=SITE_PATH?>assets/images/cs_service.png" alt="img">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- sw choose service wrapper end-->
	
	 <!--sw leads wrapper start-->
    <div class="sw_leads_wrapper grey-bg default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-lg-5 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_left_heading_wraper">
                            <h1 class="font-36" style="line-height:1.2; color:#000;"><span class="heading-bold">Få sol för ditt hem och känn skillnaden</span></h1>
                        </div>
                        <div class="row">
							<div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
								<div class="gb_icon_wrapper height-boxes">
									<div class="gb_icon_content">
										<b>Producera</b>
										<p class="get-solar-text2">Din egen energi</p>
									</div>
									<p class="get-solar-desc">Använd solljus för att producera din egen energi under soltimmarna. Det är en ren, kostnadsfri el.</p>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-xs-12 col-sm-6">
								<div class="gb_icon_wrapper height-boxes">                        
									<div class="gb_icon_content">
										<b>Överskottselektricitet</b>
										<p class="get-solar-text2">Använd den när som helst</p>
									</div>
									<p class="get-solar-desc">All producerad överskottsel säljs tillbaka till elföretaget till inköpspriset. Ingen producerad el går till spillo.</p>
								</div>
							</div>      
						</div>
			
						<div class="row">
							<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
								<div class="gb_icon_wrapper">                        
									<div class="gb_icon_content">
										<b>Återbetalningsperiod</b>
										<p class="get-solar-text2">Bäst i branschen</p>
									</div>
									<p class="get-solar-desc">Investeringen i solcentraler har en återbetalning på 8-9 år, vilket gör den till en lönsam investering. Dessutom är bidrag till miljön ett annat långsiktigt incitament att gå sol.</p>
								</div>
							</div>
						</div>
					</div>
                </div>
                <div class="col-md-7 col-lg-7 col-sm-12 col-xs-12">
					<div class="sw_road_leads_img" style="margin-top:155px;">
                        <img src="<?=SITE_PATH?>assets/images/get-solar-banner.png" alt="img">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- sw leads section end-->
	
	<div class="sw_news_letter_wrapper blue-gradiant-banner">
        <div class="container">
			<div class="row">
                <div class="col-md-1 col-lg-1 col-sm-12 col-xs-12"></div>
                <div class="col-md-10 col-lg-10 col-sm-12 col-xs-12">
					<div class="sw_nl_heading_wrapper">
						<h2 style="font-family: 'ProximaNova Regular';">Bli bara ansluten, sitt, återexportera och titta<br> <b>din solcentral kommer igång ...</b></h2>
					</div>
					<div class="sw_nl_form_wrapper">
						<div class="disc_btn ltr_btn">
							<ul>
								<li>
									<a href="<?=SITE_PATH?>fa-offert" class="waves-effect waves-light waves-ripple green-text">Ansluta</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>
	
	<div class="">
		<div class="">
			<img src="<?=SITE_PATH?>assets/images/banners/Lower-banner.jpg" class="img-responsive" alt="title">
		</div>
	</div>
	
	<div class="sw_chose_service_wrapper default-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                    <div class="sw_left_heading_wraper sw_center_heading_wrapper">
                        <h1><span class="heading-bold">Arka Energy Protection</span></h1>
                    </div>
                </div>
			</div>
                
			<div class="row">
				<div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
					<div class="gb_icon_wrapper text-center" style="padding:40px 65px">
						<div class="gb_icon_img">
							<img src="<?=SITE_PATH?>assets/images/protection/largestinsolar.png" alt="title">
						</div>	
						<div class="gb_icon_content">
							<h4>Störst i Solar</h4>
						</div>
						<p class="arka-protection-text">Vi strävar efter att vara Sveriges största solföretag som använder våra 11 års, 800 MW och 10 000 hem globala erfarenheter</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
					<div class="gb_icon_wrapper text-center" style="padding:40px 65px">
						<div class="gb_icon_img">
							<img src="<?=SITE_PATH?>assets/images/protection/customized-engery-plan.png" alt="title">
						</div>
						<div class="gb_icon_content">
							<h4>Din anpassade energiplan</h4>
						</div>
						<p class="arka-protection-text">Varje solcelleanläggning är viktig för oss. Vi skräddarsyr varje anläggning för att ge bästa möjliga behov för elbehov hos våra kunder</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
					<div class="gb_icon_wrapper text-center" style="padding:40px 65px">
						<div class="gb_icon_img">
							<img src="<?=SITE_PATH?>assets/images/protection/Customer-Support.png" alt="title">
						</div>
						<div class="gb_icon_content">
							<h4>ARKA CARE - 24 timmar Kundsupport</h4>
						</div>
						<p class="arka-protection-text">Varje solcelleanläggning är viktig för oss. Vi skräddarsyr varje anläggning för att ge bästa möjliga behov för elbehov hos våra kunder</p>
					</div>
				</div>                
			</div>
        </div>
    </div>
    <!-- sw choose service wrapper end-->
	
	
	 <div class="sw_leads_wrapper grey-bg default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="row">
							<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
								<div class="gb_icon_wrapper">                        
									<div class="mob-app-big-text">
										Kontrollera din generation<br>när du är på språng – <b> var som helst när som helst</b><br>via vår smarta klientapp
									</div>
								</div>
							</div>
						</div>
                        <div class="row">
							<div class="col-lg-4 col-md-4 col-xs-12 col-sm-4">
								<div class="mob-app-box-wrapper">
									<div class="mob-app-box-icon">
										<img src="<?=SITE_PATH?>assets/images/protection/Easytouse.png" alt="title">
									</div>
									<div class="gb_icon_content">
										<b>Lätt att använda</b>										
									</div>									
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-xs-12 col-sm-4">
								<div class="mob-app-box-wrapper">    
									<div class="mob-app-box-icon">
										<img src="<?=SITE_PATH?>assets/images/protection/allinoneapp.png" alt="title">
									</div>                   
									<div class="gb_icon_content">
										<b>Allt i en app</b>										
									</div>									
								</div>
							</div> 
							<div class="col-lg-4 col-md-4 col-xs-12 col-sm-4">
								<div class="mob-app-box-wrapper">        
									<div class="mob-app-box-icon">
										<img src="<?=SITE_PATH?>assets/images/protection/Support.png" alt="title">
									</div>                 
									<div class="gb_icon_content">
										<b>Stöd</b>										
									</div>									
								</div>
							</div> 							
						</div>	
						<div class="row">
							<div class="col-lg-12 col-md-12 col-xs-12 col-sm-4">
								<p class="working-on">We are working on it...</p>
							</div>
						</div>
					</div>
                </div>
                <div class="col-md-1 col-lg-1 col-sm-12 col-xs-12"></div>
                <div class="col-md-3 col-lg-3 col-sm-12 col-xs-12">
					<div class="sw_road_leads_img">
                        <img src="<?=SITE_PATH?>assets/images/Mobile.png" class="img-fluid">
                    </div>
                </div>
            </div>
        </div>
    </div>
	
	<div class="">
		<div class="">
			<img src="<?=SITE_PATH?>assets/images/banners/Group-167.jpg" class="img-responsive" alt="title">
		</div>
	</div>
	
	
	<div class="default-padding">
        <div class="container">
            <div class="row">
				<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                    <div class="sw_left_heading_wraper sw_center_heading_wrapper">
                        <h5><span class="heading-bold">INSTALLATIONER</span></h5>
                        <h1 style="font-size:24px; margin-top:10px;"><span class="heading-bold">Se några av våra senaste solpanelprojekt</span></h1>
                    </div>
                </div>

                <!-- slider start -->
                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12 sw_spectrm_padding">
                    <div class="spectrum_slider_wrapper">
						<div class="owl-carousel owl-theme">
							<div class="item">
								<div class="btc_blog_indx_box_wrapper btc_blog_padder btc_index_blog_pader">
									<div class="btc_blog_indx_cont_wrapper">						
										<div class="btc_blog_indx_img_wrapper">
											<img src="<?=SITE_PATH?>assets/images/Installation.jpg" alt="blog_img">
										</div>
										<div class="installation-content text-left">
											<h5>TYP</h5>	
											<div class="btc_blog_indx_cont_bottom_left">
												<p>NAMN</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="btc_blog_indx_box_wrapper btc_blog_padder btc_index_blog_pader">
									<div class="btc_blog_indx_cont_wrapper">						
										<div class="btc_blog_indx_img_wrapper">
											<img src="<?=SITE_PATH?>assets/images/Installation.jpg" alt="blog_img">
										</div>
										<div class="installation-content text-left">
											<h5>VILLA</h5>	
											<div class="btc_blog_indx_cont_bottom_left">
												<p>Cras Integer a aliquet</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="btc_blog_indx_box_wrapper btc_blog_padder btc_index_blog_pader">
									<div class="btc_blog_indx_cont_wrapper">						
										<div class="btc_blog_indx_img_wrapper">
											<img src="<?=SITE_PATH?>assets/images/Installation.jpg" alt="blog_img">
										</div>
										<div class="installation-content text-left">
											<h5>TYP</h5>	
											<div class="btc_blog_indx_cont_bottom_left">
												<p>Cras Integer a aliquet</p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="item">
								<div class="btc_blog_indx_box_wrapper btc_blog_padder btc_index_blog_pader">
									<div class="btc_blog_indx_cont_wrapper">						
										<div class="btc_blog_indx_img_wrapper">
											<img src="<?=SITE_PATH?>assets/images/Installation.jpg" alt="blog_img">
										</div>
										<div class="installation-content text-left">
											<h5>TYP</h5>	
											<div class="btc_blog_indx_cont_bottom_left">
												<p>NAMN</p>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
                </div>
				<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="disc_btn text-center">
						<ul>
							<li>
								<a href="#" class="waves-effect waves-light waves-ripple green-text green-border-btn">Fler installationer</a>
							</li>
						</ul>
					</div>
				</div>
            </div>
        </div>
    </div>
		    
	<div class="sw_chose_service_wrapper default-padding">
        <div class="container">
			<div class="sw_discver_wrapper sw_dicover_index default-padding1">
				<div class="container">
					<div class="row">
						<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
							<div class="sw_left_heading_wraper">
								<p style="font-family: 'ProximaNova Regular';"><b>Arka nyheter</b></p>
								<h1><span class="heading-bold">Bli inspirerad av solenergi</span></h1>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="sw_abt_right_btm_wrapper">
								<div class="sw_left_heading_wraper" style="padding-bottom:0px;">
									<p class="news-postdate">April 28,2021</p>
									<h2>National Resource Efficiency Policy</h2>
									<p style="padding-top:30px;font-size:15px; line-height:1.5;">The Ministry of Environment, Forests and Climate Change had proposed a draft National Resource Efficiency Policy 2019. It aims to streamline the efficient use of resources with minimum negative impact on environment...</p>
									
									<ul class="news-tags">
										<li>Information</li>
										<li>Solar Insight</li>
										<li>Technology</li>
									</ul>
									<div class="text-right">
										<p class="green-text" style="font-weight:400; margin-bottom:0px;">Read more <a href="#!" class="waves-effect waves-light waves-ripple green-text"><i class="fa fa-long-arrow-right"></i></a></p>
									</div>
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="sw_disc_txt_wrapper">
								<div class="sw_desc_btm_txt">
									<div class="sw_disc_head_text">
										<h5><a href="#">20 MW SOLAR-PROJEKT I VÄSTBENGAL <span class="next-arrow"><i class="fa fa-long-arrow-right"></i></span></a></h5>
									</div>
								</div>
								<div class="sw_desc_btm_txt">
									<div class="sw_disc_head_text">
										<h5><a href="#">HARYANA'S FÖRSTA SOLPARK UPPGIFTER AV RAYS EXPERTS <span class="next-arrow"><i class="fa fa-long-arrow-right"></i></span></a></h5>
									</div>
								</div>
								<div class="sw_desc_btm_txt">
									<div class="sw_disc_head_text">
										<h5><a href="#">UPP: 25 MW TAKSOL TENDER <span class="next-arrow"><i class="fa fa-long-arrow-right"></i></span></a></h5>
									</div>
								</div>
								<div class="sw_desc_btm_txt">
									<div class="sw_disc_head_text">
										<h5><a href="#">GROUP CAPTIVE DEN NÄSTA ATTRAKTIVA SOLMARKNADEN<span class="next-arrow"><i class="fa fa-long-arrow-right"></i></span></a></h5>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
							<div class="disc_btn text-center">
								<ul>
									<li>
										<a href="<?=SITE_PATH?>blog" class="waves-effect waves-light waves-ripple green-text green-border-btn">Se alla nyheter</a>
									</li>
								</ul>
							</div>
						</div>
					</div>				
				</div>
			</div>
		</div>	
	</div>	

	<div class="sw_chose_service_wrapper grey-bg default-padding">
        <div class="container">
			<div class="row">
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
					<div class="sw_left_heading_wraper">
						<p style="font-family: 'ProximaNova Regular';"><b>FAQ</b></p>
						<h1><span class="heading-bold">Batterier</span></h1>
					</div>
				</div>
                <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_leads_accordian">
                            <div class="panel-group" id="accordionFifteenLeft" role="tablist">
                               
                                <!-- /.panel-default -->
                                <div class="panel panel-default">
                                    <div class="panel-heading horn">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftFive" aria-expanded="false">VAD ÄR HEMLAGRINGSBATTERI OCH HUR FUNGERAR DET?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftFive" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="panel panel-default">
                                    <div class="panel-heading horn">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftTwo" aria-expanded="false">VARFÖR Behöver jag ett hemmabatteri för solenergi?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftTwo" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.panel-default -->
                                <div class="panel panel-default">
                                    <div class="panel-heading bell">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftThree" aria-expanded="false">HUR INSTALLERAR DU ETT SOLBATTERI HEMMA?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftThree" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading bell">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftFour" aria-expanded="false">KAN DU FÅ ETT SUBSIDIA FÖR INSTALLATION AV HEMLAGRINGSBATTERI?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftFour" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
								<div class="panel panel-default">
                                    <div class="panel-heading desktop">
                                        <h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftone" aria-expanded="true">HUR MYCKET KOSTNAR ETT SOLBATTERI MED INSTALLATION?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftone" class="panel-collapse collapse in" aria-expanded="true" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		</div>	
	</div>	