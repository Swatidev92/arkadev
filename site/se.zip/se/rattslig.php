<link rel="stylesheet" type="text/css" href="<?=SITE_PATH?>assets/css/inner-custom.css" />

	<div class="faq-section default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="sw_left_heading_wraper">
						<h1><span class="heading-bold">Legal</span></h1>
					</div>
				</div>
			</div>
				
			<div class="row">
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">				
					<div class="legal-title">
						<h2>Privacy Policy</h2>
					</div>
				</div>
                <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
					<div class="legal-right-box">
						<div class="legal-content">
							Arka cares for your privacy and we comply to the highest level of data protection. Please go through our privacy policy to understand how we collect and use the personal information.  
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>
    
	<div class="about-green-banner">
        <div class="container">
			<div class="row">
				<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="text-center">
						<h2 class="about-joinus"><b>Own Your Power</b></h2>
					</div>
					<div class="">
						<div class="disc_btn1 ltr_btn1 text-center">
							<ul class="about-joinus">
								<li><a href="<?=SITE_PATH?>get-connected" class="waves-effect waves-light waves-ripple">Get Connected</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>
	