<?php
//print_r($_POST);die;
extract($_POST);
if($first_name!='' && $last_name!='' && $address_input!='' && $postal_code!='' && $email!='' && $phone!=''){

	$totcost=0; $greenSubsidy=0; $netCost=0; $total_capacity=0; $annual_savings=0; $pvar=0; $upVar=0; $upfrontCost=''; $battery='No'; $car_charger='No';

	//$size = getSize($roof_area);

	if($sel_panel_type == 'Essential'){
		$pvar= 950;
	}else if($sel_panel_type == 'Design'){
		$pvar= 970;
	}else if($sel_panel_type == 'Pro'){
		$pvar= 980;
	}
	$annual_savings = getAnnualSavings($roof_area, $panel_val, $pvar);

	if($roof_area<5){
		$upVar = 16000;
	}
	else if($roof_area>5 && $roof_area<15){
		$upVar = 11300;
	}
	else{
		$upVar = 10000;
	}


	$upfrontCost = upfrontCost($roof_area, $panel_val, $upVar);
	

	if($sel_addon_type!=''){
		$addonArr = explode(',',$sel_addon_type);
		//for battery
		if(in_array('at1',$addonArr)){
			$addon_cost = 25000;
			$upfrontCost = $upfrontCost+$addon_cost;
			$battery = 'Yes';
		}
		//for charger
		if(in_array('at2',$addonArr)){
			$addon_cost = 8500;
			$upfrontCost = $upfrontCost+$addon_cost;
			$car_charger = 'Yes';
		}
	}

	$greenSubsidy = greenSubsidy($upfrontCost);
	$payback_time = getPaybackTime($upfrontCost, $greenSubsidy, $annual_savings);
	$yearlyProd = yearlyEnergyProduction($roof_area,$panel_val,$pvar);

	$_POST['total_cost'] = $upfrontCost;
	$_POST['green_subsidy'] = $greenSubsidy;
	$_POST['annual_savings'] = $annual_savings;
	$_POST['payback_time'] = $payback_time;
	$_POST['yearly_energy_production'] = $yearlyProd;
	
	//print_r($_POST);die;
	$user_map_area = $_SESSION['user_map_area'];
	$attached_img = SITE_FS_PATH.'/uploaded_files/user_map/area'.time().'.png';
	file_put_contents($attached_img, file_get_contents($user_map_area));
	//$insertId = $cms->sqlquery("rs","calculator",$_POST);

	$subject='Arka - Thank you for filling out the form!';
	$msg='Hi,<br><br><b>Thank you for showing your interest in Arka.<br>One of our experts will contact you shortly to discuss the next step.<br><br><br>Regards,<br>Arka Team';

	$email_msg= emailFormat($msg);
		
	$m1 = sendEmail($email,$subject,$email_msg);
	
	//mail to admin
	
	//$adminemail = 'sneha.techblue@gmail.com';
	$adminemail = $email;
	$adminsubject = 'Arka solar panel enquiry from '.$first_name.' '.$last_name;
	
	$admin_msg = 'Hi Admin,<br> Please find details below and attached roof area image.<br>
				<table>
					<tr><td>Name: '.$first_name.' '.$last_name.'</td></tr>
					<tr><td>Email: '.$email.'</td></tr>
					<tr><td>Phone: '.$phone.'</td></tr>
					<tr><td>Address: '.$address_input.'</td></tr>
					<tr><td>Postal Code: '.$postal_code.'</td></tr>
					<tr><td>Area: '.$roof_area.' m<sup>2</sup></td></tr>
					<tr><td>Size: '.$size.' KW</td></tr>
					<tr><td>Panels: '.$panels.' Solar Panels</td></tr>
					<tr><td>Latitude: '.$sellong.'</td></tr>
					<tr><td>Longitude: '.$sellat.' </td></tr>
					<tr><td>Slope Type: '.$slope_type.' </td></tr>
					<tr><td>Panel Type: '.$panel_type.' </td></tr>
					<tr><td>Battery: '.$battery.' </td></tr>
					<tr><td>Car Charger: '.$car_charger.' </td></tr>
					<tr><td>Upfront Cost: '.amount_format($upfrontCost).'</td></tr>
					<tr><td>Green Subsidy: '.amount_format($greenSubsidy).'</td></tr>
					<tr><td>Annual Savings: '.amount_format($annual_savings).'</td></tr>
					<tr><td>Payback Time: '.$payback_time.'</td></tr>
					<tr><td>Yearly Energy Production: '.value_format($yearlyProd).'</td></tr>
				</table>';
				
	$email_adminmsg= emailFormat($admin_msg);			
				
				//$admin_msg='test';
				
//echo $admin_msg;die;
	$m2 = sendEmail($adminemail,$adminsubject,$email_adminmsg,$attached_img);
	
	if($m1 && $m2){
	//if(1){
		echo 1;
	}else{
		echo 0;
	}
}

?>