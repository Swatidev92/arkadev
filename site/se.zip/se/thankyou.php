	<div class="contact-section grey-bg default-padding">
		<div class="container">
			<div class="holder">
				<div class="tab-content">
					<div role="tabpanel" class="tab-pane active" id="address">
						<div class="row">
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="calculator-leftbox">
									<div class="wrapper_second_useful_2">
										<div class="sw_left_heading_wraper sw_dark_heading_wraper">
											
										</div>
									</div>
								</div>
							</div>
							<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
								<div class="calculator-form-box">
										<div class="form-top-area">									
											<div class="row">									
												<div class="col-md-12">
													<div class="jumbotron1 text-center">
														<h1 class="" style="font-size:50px;margin-bottom:20px; color: green;"><i class="fa fa-check success-icon"></i></h1>
														<p class="lead">Your quote has been submitted!<br>One of our experts will contact you shortly to discuss the next step.</p>
													</div>
												</div>
											</div>
										</div>
									<!--<a class="btn btn-primary continue">Continue</a>-->
								</div>
							</div>							
						</div>					
					</div>	
				</div>
			</div>
		</div>
	</div>