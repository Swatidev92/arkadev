	<div class="page-head-banner" style="background: url(<?=SITE_PATH?>assets/images/Batteries/banner.png); background-position: center bottom; background-repeat: no-repeat; background-size: cover;">
		<div class="container">
			<div class="row">
				<div class="col-md-8">
					<div class="content-banner" style="margin-top:70px;">
						<h2>Store your excess Solar<br>Power in Battery and get<br>more savings</h2> 
						
						<div class="career-join">
							<p>Store your Solar energy and<br>become 100% self sufficient</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
 
	  <!-- sw choose service wrapper start-->
    <div class="sw_chose_service_wrapper default-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                    <div class="sw_left_heading_wraper sw_center_heading_wrapper">
                        <h1><span class="heading-bold">Låt inte din elleverantör styra ditt liv</span></h1>
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                    <div class="chose_text_wrapper_left">
                        <div class="chose_icon_wrapper_list">
                            <div class="chose_icon_content_left">
                                <h5 class="text2">Intelligent energi</h5>
                                <p class="arka-best-choice-text black-text">Spara den överflödiga producerade solenergin och använd den när som helst när det behövs</p>
                            </div>
                        </div>                   
                    </div>
                </div>
				 
                <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                    <div class="chose_text_wrapper_left">
                        <div class="chose_icon_wrapper_list">
                            <div class="chose_icon_content_left">
                                <h5 class="text2">Bli självförsörjande</h5>
                                <p class="arka-best-choice-text">Ändra Status Quo genom att producera hela konsumtionen på det mest lönsamma sättet. Varför ska stigande elpriser klämma dig varje gång</p>
                            </div>
                        </div>                      
                    </div>
                </div>
                <div class="col-lg-4 col-md-4 col-xs-12 col-sm-12">
                    <div class="chose_text_wrapper_left">
                        <div class="chose_icon_wrapper_list">
                            <div class="chose_icon_content_left">
								<h5 class="text2">Inga fler strömavbrott</h5>
                                <p class="arka-best-choice-text">Oroa dig inte när Poweris skär, bara håll ditt företag igång, tyst. Varför bränna Deisel och förorena. Inga driftskostnader längre.</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 visible-sm visible-xs">
                    <div class="section2_img_wrapper wow  bounceIn animated" data-wow-duration="1.3s" style="visibility: visible; animation-duration: 1.3s; animation-name: bounceIn;">
                        <img class="img-responsive" src="<?=SITE_PATH?>assets/images/cs_service.png" alt="img">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- sw choose service wrapper end-->
	
	
    <div class="sw_leads_wrapper default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-lg-5 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_left_heading_wraper">
                            <h1 style="line-height:1.2"><span class="heading-bold">50% skattesparande vid köp av solbatterier</span></h1>
                        </div>
						<div class="">
							<p class="get-solar-desc" style="padding-right:110px;">Äg ett solbatteri nu och få 50% skatteavdrag. Vi ser till att det görs på det mest effektiva sättet.</p>
						</div>
						<div class="disc_btn">
							<ul>
								<li>
									<a href="<?=SITE_PATH?>fa-offert" class="waves-effect waves-light waves-ripple green-text green-border-btn">Få ett citat</a>
								</li>
							</ul>
						</div>
					</div>
                </div>
                <div class="col-md-2 col-lg-2 col-sm-12 col-xs-12"></div>
                <div class="col-md-5 col-lg-5 col-sm-12 col-xs-12">
					<div class="sw_road_leads_img" style="">
                        <img src="<?=SITE_PATH?>assets/images/Batteries/Rectangle-155.png" alt="img">
                    </div>
                </div>
            </div>
        </div>
    </div>

	<div class="sw_blog_categories_2_wrapper pst grey-bg default-padding">
		<div class="container">
            <div class="row">
				<div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                    <div class="sw_left_heading_wraper sw_center_heading_wrapper">
                        <h1><span class="heading-bold">Vårt alternativ för batterier</span></h1>
                    </div>
                </div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="battery-outer">
						<div class="battery-box">
							<div class="batter-opt-top">
								<h5>Hybrid</h5>	
							</div>
							<div class="battery-option-list">
								<ul>
									<li>använder samma växelriktare för att styra dina solpaneler och ditt batteri, vilket sparar utrymme och pengar</li>
									<li>batteriet laddas med likström direkt från solpanelerna, vilket maximerar effektiviteten</li>
								</ul>
							</div>
							<p class="battery-btm-line" style="margin-top:35px;">Möjlig energilagring</p>
							<p class="battery-btm-line2">5KWH-300KWH</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="battery-outer">
						<div class="battery-box">
							<div class="batter-opt-top">
								<h5>Fristående</h5>
							</div>
							<div class="battery-option-list">
								<ul>
									<li>du har redan ett solsystem installerat på ditt tak, eller vill ha ett specifikt märke av solinverter, detta batterisystem fungerar oberoende av din solinverter.</li>
									<li>det är perfekt som en eftermontering av ditt befintliga solsystem</li>
									<li>maximerar energilagring i ett snyggt skåp</li>
								</ul>
							</div>
							<p class="battery-btm-line2">Allt-i-ett-batteri</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
					<div class="battery-outer">
						<div class="battery-box">
							<div class="batter-opt-top">
								<h5 style="margin-bottom:18px;">ESS</h5>	
							</div>
							<p class="battery-btm-line">Äg nu en solcentral i vår solpark, fyll på den med vår energilagringslösning och få kraftpriset reducerat med 70% för varje minut under många år framöver</p>
							<div class="battery-option-list" style="padding-bottom:25px;">
								<ul>
									<li>producera kraft från solenergi under dagen</li>
									<li>förvara överskottet och använd det på kvällen eller natten</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="btn-transparent text-center">
						<ul>
							<li>
								<a href="<?=SITE_PATH?>fa-offert" class="">Begär offert</a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	
    <div class="sw_leads_wrapper default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-7 col-lg-7 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_left_heading_wraper">
                            <h1 style="line-height:1.2">Byt ut dina generatoraggregat med<br>våra batterilagringslösningar</h1>
                        </div>
                        <div class="row">
							<div class="col-lg-12 col-md-12 col-xs-12 col-sm-6">
								<div class="">
									<p class="para-content">När strömmen bryts sätter kraften på generatorn, som bränner deisel för att producera kraft. Dessa är mycket förorenande och kostar 3 gånger kostnaden för vanlig el. Över det använder dessa generatorer mycket utrymme och är höga kapital- och driftskostnader.</p>
									<p class="para-content">Byt nu ut dessa generatoraggregat med våra batterilagringslösningar, ladda dessa batterier under normala belastningar och ladda ur antingen enligt ett fixschema eller när det är strömavbrott.<br>Dessa urladdningsmönster kan kontrolleras via vår app. Detta system kan monteras retro i alla inställningar.</p>
								</div>
							</div>							      
						</div>
					</div>
                </div>
            </div>
        </div>
    </div>
	
	
	<div class="sw_chose_service_wrapper grey-bg default-padding">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-xs-12 col-sm-12">
                    <div class="sw_left_heading_wraper sw_center_heading_wrapper">
						<p class="logo-color"><b>SOLARBATTERIPROCESSEN</b></p>
                        <h1><span class="heading-bold">Hur vi hjälper dig</span></h1>
                    </div>
                </div>
			</div>
                
			<div class="row">
				<div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
					<div class="outer-process-box">
						<div class="gb_icon_wrapper text-center battery-help-box">
							<div class="gb_icon_img">
								<img src="<?=SITE_PATH?>assets/images/Batteries/icon1.png" alt="title" width="50">
							</div>	
							<div class="gb_icon_content">
								<h4>Förstå kravet</h4>
							</div>
							<p>Vi beräknar och analyserar din solproduktion och energiförbrukning.</p>
						</div>
					</div>
					<div class="flow-arrow">
						<img src="<?=SITE_PATH?>assets/images/Batteries/Arrow3.png" alt="title">
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
					<div class="outer-process-box">
						<div class="gb_icon_wrapper text-center battery-help-box">
							<div class="gb_icon_img">
								<img src="<?=SITE_PATH?>assets/images/Batteries/icon2.png" alt="title" width="50">
							</div>
							<div class="gb_icon_content">
								<h4>Välj ditt batteri</h4>
							</div>
							<p>Baserat på vår beräkning rekommenderar vi att du väljer de bästa alternativen för batterikonfiguration</p>
						</div>					
					</div>					
					<div class="flow-arrow">
						<img src="<?=SITE_PATH?>assets/images/Batteries/Arrow3.png" alt="title" width="50">
					</div>
				</div>
				<div class="col-lg-4 col-md-4 col-xs-12 col-sm-6">
					<div class="outer-process-box">
						<div class="gb_icon_wrapper text-center battery-help-box">
							<div class="gb_icon_img">
								<img src="<?=SITE_PATH?>assets/images/Batteries/icon3.png" alt="title">
							</div>
							<div class="gb_icon_content">
								<h4>Installation</h4>
							</div>
							<p>Medan vi installerar dina solpaneler och batterier lutar du dig tillbaka och återexperterar</p>
						</div>
					</div>
				</div>                
			</div>
        </div>
    </div>
		
	<div class="sw_news_letter_wrapper default-padding battery-gradiant-banner">
        <div class="container">
			<div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="sw_nl_heading_wrapper">
						<h2 style="font-family: 'ProximaNova Regular';">Vill du arbeta med oss mot en mer<br>hållbar framtid?</b></h2>
					</div>
					<div class="sw_nl_form_wrapper">
						<div class="disc_btn ltr_btn">
							<ul>
								<li>
									<a href="#!" class="waves-effect waves-light waves-ripple">Get Connected</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
        </div>
    </div>
	
	
	<div class="sw_chose_service_wrapper default-padding">
        <div class="container">
			<div class="row">
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
					<div class="sw_left_heading_wraper">
						<p style="font-family: 'ProximaNova Regular';"><b>FAQ</b></p>
						<h1><span class="heading-bold">Batterier</span></h1>
					</div>
					
					<div class="faqs-more">
						<p class="" style="font-weight:400; margin-bottom:0px; color:#c5c5c5;"><a href="#!" class="waves-effect waves-light waves-ripple">Mer <i class="fa fa-long-arrow-right"></i></a></p>
					</div>
				</div>
                <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
                    <div class="sw_disc_txt_wrapper">
                        <div class="sw_leads_accordian">
                            <div class="panel-group" id="accordionFifteenLeft" role="tablist">
                               
                                <!-- /.panel-default -->
                                <div class="panel panel-default">
                                    <div class="panel-heading horn">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftFive" aria-expanded="false">What is a home storage battery and how does it work?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftFive" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="panel panel-default">
                                    <div class="panel-heading horn">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftTwo" aria-expanded="false">Why do I need a home battery for solar energy?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftTwo" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- /.panel-default -->
                                <div class="panel panel-default">
                                    <div class="panel-heading bell">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftThree" aria-expanded="false">How do you install a solar battery at home?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftThree" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading bell">
                                        <h4 class="panel-title">
											<a class="collapsed" data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftFour" aria-expanded="false">Can you get a subsidy for installing a home storage battery?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftFour" class="panel-collapse collapse" aria-expanded="false" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								
								<div class="panel panel-default">
                                    <div class="panel-heading desktop">
                                        <h4 class="panel-title">
											<a data-toggle="collapse" data-parent="#accordionFifteenLeft" href="#collapseFifteenLeftone" aria-expanded="true">How much does a solar battery with installation cost?</a>
										</h4>
                                    </div>
                                    <div id="collapseFifteenLeftone" class="panel-collapse collapse in" aria-expanded="true" role="tabpanel">
                                        <div class="panel-body">

                                            <div class="panel_cont">
                                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Adipiscing pellentesque nec molestie orci varius. Tortor magna lorem aenean nibh sed ac purus volutpat venenatis. Ultrices commodo enim enim cras euismod aenean sociis. Accumsan massa, phasellus dolor arcu. Quis in suspendisse senectus quam aenean pharetra. Cras pellentesque viverra quis euismod vel magna.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		</div>	
	</div>	