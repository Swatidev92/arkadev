<link rel="stylesheet" type="text/css" href="<?=SITE_PATH?>assets/css/inner-custom.css" />

	<div class="faq-section default-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="sw_left_heading_wraper">
						<h1><span class="heading-bold">Contact Us</span></h1>
					</div>
				</div>
			</div>
					
            <div class="row">
                <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
					<div class="row">
						<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Contact Us</h2>
								</div>
								<div class="contact-content">
									If you are also into solar power we would love to hear from you. If you want us to visit, then say so
								</div>
								<div class="contact-btns">
									<a class="transparent-btn" href="">Say Hello</a>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Get Connected</h2>
								</div>
								<div class="contact-content">
									If you are also into solar power we would love to hear from you. If you want us to visit, then say so
								</div>
								<div class="contact-btns">
									<a class="transparent-btn" href="<?=SITE_PATH?>get-connected">Get Connected</a>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Become a Ambassador</h2>
								</div>
								<div class="contact-content">
									Contribute to society through our Ambassador programme
								</div>
								<div class="contact-btns">
									<a class="transparent-btn" href="<?=SITE_PATH?>get-connected">Know More</a>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Career</h2>
								</div>
								<div class="contact-content">
									Do you want to work with us towards a more sustainable future? Ray Experts is growing and right now we have many exciting vacancies.
								</div>
								<div class="contact-btns">
									<a class="transparent-btn" href="<?=SITE_PATH?>careers">Careers</a>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Support</h2>
								</div>
								<div class="contact-content">
									Need quick help? Log in and submit a case, and someone from our helpful support team will contact you
								</div>
								<div class="contact-btns">
									<a class="transparent-btn" href="<?=SITE_PATH?>#">Contact Us</a>
								</div>
							</div>
						</div>
						<div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Legal</h2>
								</div>
								<div class="contact-content">
									Need legal support in matters concerning your solar energy system from Svea Solar? Contact our legal team for advice
								</div>
								<div class="contact-btns">
									<a class="transparent-btn" href="<?=SITE_PATH?>#">Contact Us</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
                <div class="col-md-4 col-lg-4 col-sm-12 col-xs-12">
					<div class="sw_left_heading_wraper">
						<h1><span class="heading-bold">Visit Us</span></h1>
					</div>
				</div>
                <div class="col-md-8 col-lg-8 col-sm-12 col-xs-12">
					<div class="row">
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Head Office</h2>
								</div>
								<div class="contact-content">
									4th Floor Sheel Mohar Plaza Yudhisthir Marg
								</div>
								<br>
								<div class="contact-content">
									C Scheme, Jaipur, Rajasthan 302001
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Emails</h2>
								</div>
								<div class="contact-content contact-email">
									<a href="mailto:info@raysexperts.com">info@raysexperts.com</a>
								</div>
								<div class="contact-content contact-email">
									<a href="mailto:info@raysrooftop.com">info@raysrooftop.com</a>
								</div>
								<div class="contact-content contact-email">
									<a href="mailto:marketing@raysexperts.com">marketing@raysexperts.com</a>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Overseas Office</h2>
								</div>
								<div class="contact-content">
									5 Shenton Way
								</div>
								<br>
								<div class="contact-content">
									UIC Building #10-01, Singapore 068808
								</div>
							</div>
						</div>
						<div class="col-md-6 col-lg-6 col-sm-12 col-xs-12">
							<div class="contact-right-box">
								<div class="contact-title">
									<h2>Phone Numbers</h2>
								</div>
								<div class="contact-content contact-email">
									<a href="tel:+91-7414040111">+91-7414040111</a>
								</div>
								<div class="contact-content contact-email">
									<a href="tel:+91-(141)-2220140">+91-(141)-2220140</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
    </div>